//
//  CircularProgressView.swift
//  Taubah Watch App
//
//  Created by Putra Pangestu on 22/05/24.
//

import SwiftUI

struct CircularProgressView: View {
    @Binding var progress: Double
    var pecahanatas: Double = 18
    var pecahanbawah: Double = 12
    var circle: Double = 12
    
    var body: some View {
        ZStack {
            Circle()
                .stroke(lineWidth: circle)
                .opacity(0.2)
                .foregroundColor(Color.white)
            
            Circle()
                .trim(from: 0.0, to: CGFloat(min(self.progress, 10.0)))
                .stroke(style: StrokeStyle(lineWidth: circle, lineCap: .round, lineJoin: .round))
                .foregroundColor(Color.white)
                .rotationEffect(Angle(degrees: 270.0))
                .animation(.linear, value: progress)
            
//            Text(String(format: "%.0f%%", min(self.progress, 1.0) * 100.0))
//                .font(.system(size: 18))
//                .bold()
            VStack (spacing: 0) {
                Text("\(Int(self.progress * 100))")
                    .font(.system(size: pecahanatas))
                    .fontWeight(.bold)
                    
                Text("/100")
                    .font(.system(size: pecahanbawah))
                    .fontWeight(.medium)
            }
        }
    }
}



struct CircularProgressView_Previews: PreviewProvider {
    static var previews: some View {
        CircularProgressView(progress: .constant(0.5))
    }
}
