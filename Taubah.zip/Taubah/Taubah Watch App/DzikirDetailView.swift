import SwiftUI
import WatchKit
import AVFoundation

struct DzikirDetailView: View {
    @Binding var dzikir: Dzikir
    @State private var crownValue: Double = 0.10
    @State private var audioPlayer: AVAudioPlayer?

    var body: some View {
        TabView {
            ZStack {
                LinearGradient(gradient: Gradient(colors: [dzikir.color.opacity(0.6), dzikir.color.opacity(0)]),
                               startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                Image("grap")
                    .padding(.bottom, 190.0)
                
                VStack(spacing: 8) {
                    CircularProgressView(progress: $dzikir.progress, pecahanatas: 18, pecahanbawah: 12, circle: 8)
                        .frame(width: 68, height: 68)
                        .navigationTitle(dzikir.title)
                    
                    VStack(spacing: 4) {
                        Text("Complete your daily dhikr target")
                            .font(.footnote)
                            .multilineTextAlignment(.center)
                        
                        HStack(spacing: 6) {
                            Image(systemName: "hand.tap")
                                .foregroundColor(.white)
                                .font(.title3)
                            
                            Text("or")
                                .font(.body)
                            
                            Image(systemName: "digitalcrown.arrow.clockwise")
                                .foregroundColor(.white)
                                .font(.title3)
                        }
                    }
                }
                .padding(.top, 20.0)
                .focusable(true)
                .digitalCrownRotation($crownValue, from: 0.0, through: 10.0, by: 0.001, sensitivity: .low)
                .onChange(of: crownValue) { newValue in
                    withAnimation {
                        dzikir.progress = newValue
                        WKInterfaceDevice.current().play(.click)
                        playAudio()
                    }
                }
            }
            .onTapGesture {
                withAnimation {
                    if dzikir.progress < 10.0 {
                        dzikir.progress += 0.01
                    } else {
                        dzikir.progress = 0.0
                    }
                    WKInterfaceDevice.current().play(.click)
                    playAudio()
                }
            }
            
            ZStack {
                LinearGradient(gradient: Gradient(colors: [dzikir.color.opacity(0.6), dzikir.color.opacity(0)]),
                               startPoint: .top, endPoint: .bottom)
                    .edgesIgnoringSafeArea(.all)
                
                Image("grap")
                    .padding(.bottom, 190.0)
                
                Button(action: {
                    dzikir.progress = 0.0
                    WKInterfaceDevice.current().play(.success)
                    playAudio()
                }) {
                    Text("Reset")
                        
                        .foregroundColor(.white)
                        
                }
                .background(dzikir.color)
                .cornerRadius(30)
            }
        }
        .tabViewStyle(PageTabViewStyle())
        .onAppear {
            setupAudioPlayer()
        }
    }
    
    // Setup the audio player
    func setupAudioPlayer() {
        if let sound = Bundle.main.url(forResource: "tick", withExtension: "mp3") {
            do {
                audioPlayer = try AVAudioPlayer(contentsOf: sound)
                audioPlayer?.prepareToPlay()
            } catch {
                print("Error loading audio file: \(error)")
            }
        }
    }

    // Play the audio
    func playAudio() {
        audioPlayer?.play()
    }
}

struct DzikirDetailView_Previews: PreviewProvider {
    static var previews: some View {
        DzikirDetailView(dzikir: .constant(Dzikir(
            title: "SubhanAllah",
            keyword: "Clarity, Astonishment",
            color: Color.red, // Replace Color.subha with Color.red for this example
            bground: "bgred",
            latin: "Subha",
            lafas: "سُبْحَانَ الله",
            progress: 0.1
        )))
    }
}
