//
//  TaubahApp.swift
//  Taubah Watch App
//
//  Created by Putra Pangestu on 22/05/24.
//

import SwiftUI

@main
struct Taubah_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
