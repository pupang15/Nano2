//
//  DzikirCardView.swift
//  Taubah Watch App
//
//  Created by Putra Pangestu on 22/05/24.
//

import SwiftUI

struct DzikirCardView: View {
    @Binding var dzikir: Dzikir
    
    var body: some View {
        VStack(alignment: .trailing, spacing: 6) {
            HStack {
                CircularProgressView(progress: $dzikir.progress, pecahanatas: 8, pecahanbawah: 8, circle: 3) // Add circular progress
                    .frame(width: 30, height: 30)
//                    .onTapGesture {
//                        if dzikir.progress < 1.0 {
//                            dzikir.progress += 0.1
//                        } else {
//                            dzikir.progress = 0.0
//                        }
//                    }
                Spacer()
                
                Text(dzikir.lafas)
                    .font(Font.custom("Sana", size: 24))
            }
            .frame(maxWidth: .infinity)
            
            Text(dzikir.title)
                .font(.system(size: 16))
                .fontWeight(.bold)
                .padding(.bottom, 2)
            
            Text(dzikir.keyword)
                .font(.system(size: 12))
        }
        .padding(.all, 10)
        .frame(maxWidth: .infinity, minHeight: 100, alignment: .trailing)
        .background(Image(dzikir.bground))
        .cornerRadius(18)
        .shadow(radius: 5)
    }
}
struct DzikirCardView_Previews: PreviewProvider {
    static var previews: some View {
        DzikirCardView(dzikir: .constant(Dzikir(title: "Subhanallah", keyword: "Calam", color: .blue , bground: "bgred", latin: "Subhana", lafas: "سُبْحَانَ الله")))
//        DzikirCardView(progress: .constant(0.5), progressize: 24)
    }
}
