//
//  Dzikir.swift
//  Taubah Watch App
//
//  Created by Putra Pangestu on 22/05/24.
//

import SwiftUI

struct Dzikir: Identifiable {
    var id = UUID()
    var title: String
    var keyword: String
    var color: Color
    var bground: String
    var latin: String
    var lafas: String
    var progress: Double = 0.0  // Add progress state
}
