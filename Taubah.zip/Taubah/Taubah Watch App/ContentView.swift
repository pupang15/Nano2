//
//  ContentView.swift
//  Taubah Watch App
//
//  Created by Putra Pangestu on 22/05/24.
//

import SwiftUI

struct ContentView: View {
    @State private var dzikirs = [
        Dzikir(title: "SubhanAllah" , keyword: "Clarity, Astonishment", color: Color.subha, bground: "bgred", latin: "Subha", lafas: "سُبْحَانَ الله", progress: 0.0),
        Dzikir(title: "Alhamdulillah", keyword: "Gratitude, Mindfulness", color: Color.alham, bground: "bgtale", latin: "Alham", lafas: "اَلْحَمْدُ لِلَّهِ",  progress: 0.21),
        Dzikir(title: "Lailahaillallah", keyword: "One, Peace, True", color: Color.laila, bground: "bgpurple", latin: "Laila", lafas: "لَا إِلَهَ إِلَّا اللَّهُ",  progress: 0.0),
        Dzikir(title: "Allahu Akbar", keyword: "Awe, Reverence", color: Color.allahu, bground: "bgyellow", latin: "Allahu", lafas: "ٱللَّٰهُ أَكْبَرُ", progress: 0)
    ]
    
    var body: some View {
        GeometryReader { outerGeometry in
            NavigationStack {
                ScrollView {
                    VStack(alignment: .center, spacing: 2) {
                        ForEach($dzikirs) { $dzikir in
                            NavigationLink(destination: DzikirDetailView(dzikir: $dzikir)) {
                                GeometryReader { innerGeometry in
                                    DzikirCardView(dzikir: $dzikir)
                                        .scaleEffect(scaleFactor(outerGeometry: outerGeometry, innerGeometry: innerGeometry))
                                }
                                .frame(height: 89)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                }
                .navigationTitle("Taubah")
            }
        }
        .edgesIgnoringSafeArea(.all)
    }
    
    private func scaleFactor(outerGeometry: GeometryProxy, innerGeometry: GeometryProxy) -> CGFloat {
        let midY = outerGeometry.frame(in: .global).midY
        let cardMidY = innerGeometry.frame(in: .global).midY
        let distance = abs(midY - cardMidY)
        let scale = max(0.8, 1 - (distance / outerGeometry.size.height))
        return scale
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
