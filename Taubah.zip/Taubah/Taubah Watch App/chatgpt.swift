import SwiftUI

struct HorizontalTwoPageTabView: View {
    var body: some View {
        TabView {
            Text("First Page")
                .font(.largeTitle)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.blue)
                .foregroundColor(.white)
            
        Text ("Hello")
            
            Text("Second Page")
                .font(.largeTitle)
                .fontWeight(.bold)
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(Color.green)
                .foregroundColor(.white)
        }
        .tabViewStyle(PageTabViewStyle())
    }
}

struct HorizontalTwoPageTabView_Previews: PreviewProvider {
    static var previews: some View {
        HorizontalTwoPageTabView()
    }
}
